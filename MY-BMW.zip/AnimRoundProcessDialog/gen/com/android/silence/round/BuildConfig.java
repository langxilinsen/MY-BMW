/** Automatically generated file. DO NOT MODIFY */
package com.android.silence.round;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}