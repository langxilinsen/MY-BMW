/** Automatically generated file. DO NOT MODIFY */
package com.chonwhite.android.snippets.listview;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}