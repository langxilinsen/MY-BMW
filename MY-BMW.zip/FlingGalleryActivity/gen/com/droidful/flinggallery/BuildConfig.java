/** Automatically generated file. DO NOT MODIFY */
package com.droidful.flinggallery;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}