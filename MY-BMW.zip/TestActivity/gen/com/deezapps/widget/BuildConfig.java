/** Automatically generated file. DO NOT MODIFY */
package com.deezapps.widget;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}